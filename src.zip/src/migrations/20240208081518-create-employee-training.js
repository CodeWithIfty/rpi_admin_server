'use strict';
/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('EmployeeTrainings', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      username: {
        type: Sequelize.STRING
      },
      employee_name: {
        type: Sequelize.STRING
      },
      employee_training_type: {
        type: Sequelize.STRING
      },
      employee_training_institute_name: {
        type: Sequelize.STRING
      },
      employee_training_course_title: {
        type: Sequelize.STRING
      },
      employee_training_duration_from: {
        type: Sequelize.DATE
      },
      employee_training_duration_to: {
        type: Sequelize.DATE
      },
      employee_training_result: {
        type: Sequelize.STRING
      },
      employee_training_office_order_no: {
        type: Sequelize.STRING
      },
      employee_training_job_category: {
        type: Sequelize.STRING
      },
      employee_training_country: {
        type: Sequelize.STRING
      },
      employee_training_go_document: {
        type: Sequelize.STRING
      },
      employee_training_go_document_name: {
        type: Sequelize.STRING
      },
      employee_training_certificate_document: {
        type: Sequelize.STRING
      },
      employee_training_certificate_document_name: {
        type: Sequelize.STRING
      },
      employee_training_certificate_number: {
        type: Sequelize.STRING
      },
      employee_training_certificate_date: {
        type: Sequelize.DATE
      },
      employee_training_organization_type: {
        type: Sequelize.STRING
      },
      employee_training_work_area: {
        type: Sequelize.STRING
      },
      employee_training_active_status: {
        type: Sequelize.BOOLEAN
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable('EmployeeTrainings');
  }
};