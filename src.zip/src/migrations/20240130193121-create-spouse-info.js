'use strict';
/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('spouse_infos', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      employee_name: {
        type: Sequelize.STRING
      },
      spouse_name_english: {
        type: Sequelize.STRING
      },
      spouse_name_bangla: {
        type: Sequelize.STRING
      },
      spouse_date_of_birth: {
        type: Sequelize.DATE
      },
      spouse_gender: {
        type: Sequelize.STRING
      },
      spouse_relationship: {
        type: Sequelize.STRING
      },
      is_spouse_nominee: {
        type: Sequelize.BOOLEAN
      },
      spouse_occupation: {
        type: Sequelize.STRING
      },
      spouse_organization: {
        type: Sequelize.STRING
      },
      spouse_organization_type: {
        type: Sequelize.STRING
      },
      spouse_work_area: {
        type: Sequelize.STRING
      },
      spouse_designation: {
        type: Sequelize.STRING
      },
      spouse_nid: {
        type: Sequelize.STRING
      },
      spouse_mobile_number: {
        type: Sequelize.STRING
      },
      spouse_address: {
        type: Sequelize.STRING
      },
      spouse_active_status: {
        type: Sequelize.BOOLEAN
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable('spouse_infos');
  }
};