'use strict';
/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('teacher_infos', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      teacherNameEnglish: {
        type: Sequelize.STRING
      },
      teacherNameBangla: {
        type: Sequelize.STRING
      },
      teacherMobileNumber: {
        type: Sequelize.STRING
      },
      teacherDesignation: {
        type: Sequelize.STRING
      },
      rpiJoiningDate: {
        type: Sequelize.DATE
      },
      dateOfBirth: {
        type: Sequelize.DATE
      },
      nidNumber: {
        type: Sequelize.STRING
      },
      pdsNo: {
        type: Sequelize.STRING
      },
      address: {
        type: Sequelize.STRING
      },
      img: {
        type: Sequelize.STRING
      },
      dept: {
        type: Sequelize.STRING
      },
      shift: {
        type: Sequelize.STRING
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable('teacher_infos');
  }
};