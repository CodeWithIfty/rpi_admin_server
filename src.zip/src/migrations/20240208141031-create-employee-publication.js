'use strict';
/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('EmployeePublications', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      username: {
        type: Sequelize.STRING
      },
      employee_name: {
        type: Sequelize.STRING
      },
      employee_publication_title: {
        type: Sequelize.STRING
      },
      employee_publication_organization_or_institute: {
        type: Sequelize.STRING
      },
      employee_publication_type: {
        type: Sequelize.STRING
      },
      employee_publication_link: {
        type: Sequelize.STRING
      },
      employee_publication_date: {
        type: Sequelize.DATE
      },
      employee_publication_remarks: {
        type: Sequelize.STRING
      },
      employee_publication_document: {
        type: Sequelize.STRING
      },
      employee_publication_document_name: {
        type: Sequelize.STRING
      },
      employee_training_type: {
        type: Sequelize.STRING
      },
      employee_publication_active_status: {
        type: Sequelize.BOOLEAN
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable('EmployeePublications');
  }
};