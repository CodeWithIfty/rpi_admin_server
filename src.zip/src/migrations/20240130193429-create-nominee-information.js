'use strict';
/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('NomineeInformations', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      employee_name: {
        type: Sequelize.STRING
      },
      nominee_name_english: {
        type: Sequelize.STRING
      },
      nominee_name_bangla: {
        type: Sequelize.STRING
      },
      nominee_date_of_birth: {
        type: Sequelize.DATE
      },
      nominee_gender: {
        type: Sequelize.STRING
      },
      nominee_relationship: {
        type: Sequelize.STRING
      },
      nominee_organization_type: {
        type: Sequelize.STRING
      },
      nominee_organization: {
        type: Sequelize.STRING
      },
      nominee_occupation: {
        type: Sequelize.STRING
      },
      nominee_designation: {
        type: Sequelize.STRING
      },
      nominee_nid: {
        type: Sequelize.STRING
      },
      nominee_mobile_number: {
        type: Sequelize.STRING
      },
      nominee_address: {
        type: Sequelize.STRING
      },
      nominee_active_status: {
        type: Sequelize.BOOLEAN
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable('NomineeInformations');
  }
};