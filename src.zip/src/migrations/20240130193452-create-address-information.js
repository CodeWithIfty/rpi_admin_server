'use strict';
/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('AddressInformations', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      organization_type: {
        type: Sequelize.STRING
      },
      institute_name: {
        type: Sequelize.STRING
      },
      address_type: {
        type: Sequelize.STRING
      },
      house_number_english: {
        type: Sequelize.STRING
      },
      road_number_english: {
        type: Sequelize.STRING
      },
      village_name_english: {
        type: Sequelize.STRING
      },
      post_office_english: {
        type: Sequelize.STRING
      },
      post_code: {
        type: Sequelize.STRING
      },
      division: {
        type: Sequelize.STRING
      },
      district: {
        type: Sequelize.STRING
      },
      upazila: {
        type: Sequelize.STRING
      },
      mobile_number: {
        type: Sequelize.STRING
      },
      address_active_status: {
        type: Sequelize.BOOLEAN
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable('AddressInformations');
  }
};