'use strict';
/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('EmployeeActingDuties', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      username: {
        type: Sequelize.STRING
      },
      employee_name: {
        type: Sequelize.STRING
      },
      employee_acting_duty_from_organization_type: {
        type: Sequelize.STRING
      },
      employee_acting_duty_from_institute: {
        type: Sequelize.STRING
      },
      employee_acting_duty_from_department: {
        type: Sequelize.STRING
      },
      employee_acting_duty_from_designation: {
        type: Sequelize.STRING
      },
      employee_acting_duty_from_date: {
        type: Sequelize.DATE
      },
      employee_acting_duty_to_organization_type: {
        type: Sequelize.STRING
      },
      employee_acting_duty_to_institute: {
        type: Sequelize.STRING
      },
      employee_acting_duty_to_department: {
        type: Sequelize.STRING
      },
      employee_acting_duty_to_designation: {
        type: Sequelize.STRING
      },
      employee_acting_duty_to_date: {
        type: Sequelize.DATE
      },
      employee_acting_duty_officer_order_no: {
        type: Sequelize.STRING
      },
      employee_acting_duty_officer_order_date: {
        type: Sequelize.DATE
      },
      employee_acting_duty_description: {
        type: Sequelize.STRING
      },
      employee_acting_duty_comments: {
        type: Sequelize.STRING
      },
      employee_acting_duty_go_date: {
        type: Sequelize.DATE
      },
      employee_acting_duty_go_document: {
        type: Sequelize.STRING
      },
      employee_acting_duty_go_document_name: {
        type: Sequelize.STRING
      },
      employee_acting_duty_active_status: {
        type: Sequelize.STRING
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable('EmployeeActingDuties');
  }
};