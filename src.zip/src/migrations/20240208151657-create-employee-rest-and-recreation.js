'use strict';
/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('EmployeeRestAndRecreations', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      username: {
        type: Sequelize.STRING
      },
      employee_name: {
        type: Sequelize.STRING
      },
      employee_rest_and_recreation_eligibility_date: {
        type: Sequelize.DATE
      },
      employee_rest_and_recreation_basic_salary: {
        type: Sequelize.DECIMAL
      },
      employee_rest_and_recreation_total_days: {
        type: Sequelize.INTEGER
      },
      employee_rest_and_recreation_memo_number: {
        type: Sequelize.STRING
      },
      employee_rest_and_recreation_officer_order_date: {
        type: Sequelize.DATE
      },
      employee_rest_and_recreation_leave_from_date: {
        type: Sequelize.DATE
      },
      employee_rest_and_recreation_leave_to_date: {
        type: Sequelize.DATE
      },
      employee_rest_and_recreation_reason_for_not_taken: {
        type: Sequelize.STRING
      },
      employee_rest_and_recreation_active_status: {
        type: Sequelize.STRING
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable('EmployeeRestAndRecreations');
  }
};