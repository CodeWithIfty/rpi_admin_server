'use strict';
/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('EmployeeProfessionalMemberships', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      username: {
        type: Sequelize.STRING
      },
      employee_name: {
        type: Sequelize.STRING
      },
      employee_professional_membership_organization_name: {
        type: Sequelize.STRING
      },
      employee_professional_membership_taken_from: {
        type: Sequelize.DATE
      },
      employee_professional_membership_number: {
        type: Sequelize.STRING
      },
      employee_professional_membership_date: {
        type: Sequelize.DATE
      },
      employee_professional_membership_active_status: {
        type: Sequelize.STRING
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable('EmployeeProfessionalMemberships');
  }
};