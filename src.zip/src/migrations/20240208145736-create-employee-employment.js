'use strict';
/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('EmployeeEmployments', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      username: {
        type: Sequelize.STRING
      },
      employee_name: {
        type: Sequelize.STRING
      },
      employee_employment_type: {
        type: Sequelize.STRING
      },
      employee_employment_present_basic_scale: {
        type: Sequelize.STRING
      },
      employee_employment_select_locality: {
        type: Sequelize.STRING
      },
      employee_employment_present_institute: {
        type: Sequelize.STRING
      },
      employee_employment_date_of_joining: {
        type: Sequelize.DATE
      },
      employee_employment_date_of_regularization: {
        type: Sequelize.DATE
      },
      employee_employment_job_confirmation_no: {
        type: Sequelize.STRING
      },
      employee_employment_date_of_confirmation: {
        type: Sequelize.DATE
      },
      employee_employment_officer_order_no: {
        type: Sequelize.STRING
      },
      employee_employment_officer_order_date: {
        type: Sequelize.DATE
      },
      employee_employment_active_status: {
        type: Sequelize.STRING
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable('EmployeeEmployments');
  }
};