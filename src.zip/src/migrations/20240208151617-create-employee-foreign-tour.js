'use strict';
/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('EmployeeForeignTours', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      username: {
        type: Sequelize.STRING
      },
      employee_name: {
        type: Sequelize.STRING
      },
      employee_job_category: {
        type: Sequelize.STRING
      },
      employee_foreign_tour_country_name: {
        type: Sequelize.STRING
      },
      employee_foreign_tour_purpose: {
        type: Sequelize.STRING
      },
      employee_foreign_tour_from_date: {
        type: Sequelize.DATE
      },
      employee_foreign_tour_to_date: {
        type: Sequelize.DATE
      },
      employee_foreign_tour_officer_order_date: {
        type: Sequelize.DATE
      },
      employee_foreign_tour_officer_order_number: {
        type: Sequelize.STRING
      },
      employee_foreign_tour_source_of_fund: {
        type: Sequelize.STRING
      },
      employee_foreign_tour_go_number: {
        type: Sequelize.STRING
      },
      employee_foreign_tour_go_date: {
        type: Sequelize.DATE
      },
      employee_foreign_tour_go_document: {
        type: Sequelize.STRING
      },
      employee_foreign_tour_go_document_name: {
        type: Sequelize.STRING
      },
      employee_foreign_tour_active_status: {
        type: Sequelize.STRING
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable('EmployeeForeignTours');
  }
};