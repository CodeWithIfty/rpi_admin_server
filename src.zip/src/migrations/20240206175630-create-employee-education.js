'use strict';
/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('EmployeeEducations', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      employee_name: {
        type: Sequelize.STRING
      },
      employee_education_level: {
        type: Sequelize.STRING
      },
      employee_education_board_university: {
        type: Sequelize.STRING
      },
      employee_education_exam_title: {
        type: Sequelize.STRING
      },
      employee_education_group_or_subject: {
        type: Sequelize.STRING
      },
      employee_education_certificate_serial_no: {
        type: Sequelize.STRING
      },
      employee_education_session_year: {
        type: Sequelize.STRING
      },
      employee_education_roll_number: {
        type: Sequelize.STRING
      },
      employee_education_institute_name: {
        type: Sequelize.STRING
      },
      employee_education_result: {
        type: Sequelize.STRING
      },
      employee_education_certificate_document: {
        type: Sequelize.STRING
      },
      employee_education_transcript_document: {
        type: Sequelize.STRING
      },
      employee_education_testimonial_document: {
        type: Sequelize.STRING
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable('EmployeeEducations');
  }
};