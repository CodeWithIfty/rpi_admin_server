'use strict';
/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('employe_infos', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      full_name_english: {
        type: Sequelize.STRING
      },
      full_name_bangla: {
        type: Sequelize.STRING
      },
      date_of_birth: {
        type: Sequelize.DATE
      },
      mobile_number: {
        type: Sequelize.STRING
      },
      nid: {
        type: Sequelize.STRING
      },
      email: {
        type: Sequelize.STRING
      },
      district: {
        type: Sequelize.STRING
      },
      upazila: {
        type: Sequelize.STRING
      },
      post: {
        type: Sequelize.STRING
      },
      address: {
        type: Sequelize.STRING
      },
      father_name_english: {
        type: Sequelize.STRING
      },
      father_name_bangla: {
        type: Sequelize.STRING
      },
      mother_name_english: {
        type: Sequelize.STRING
      },
      mother_name_bangla: {
        type: Sequelize.STRING
      },
      quota: {
        type: Sequelize.STRING
      },
      appointment_date_go: {
        type: Sequelize.DATE
      },
      joining_date_on_gov_service: {
        type: Sequelize.DATE
      },
      date_of_joining_current_organization: {
        type: Sequelize.DATE
      },
      date_of_confirmation: {
        type: Sequelize.DATE
      },
      joining_date_of_present_position: {
        type: Sequelize.DATE
      },
      job_category: {
        type: Sequelize.STRING
      },
      job_status: {
        type: Sequelize.STRING
      },
      employment_status: {
        type: Sequelize.STRING
      },
      requirement_type: {
        type: Sequelize.STRING
      },
      employee_type: {
        type: Sequelize.STRING
      },
      curriculum_name: {
        type: Sequelize.STRING
      },
      subject: {
        type: Sequelize.STRING
      },
      section_department: {
        type: Sequelize.STRING
      },
      grade_information: {
        type: Sequelize.STRING
      },
      designation: {
        type: Sequelize.STRING
      },
      encadrement: {
        type: Sequelize.STRING
      },
      employment_type: {
        type: Sequelize.STRING
      },
      date_of_retirement: {
        type: Sequelize.DATE
      },
      date_of_prl: {
        type: Sequelize.DATE
      },
      is_cadder: {
        type: Sequelize.STRING
      },
      cadder_level: {
        type: Sequelize.STRING
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable('employe_infos');
  }
};