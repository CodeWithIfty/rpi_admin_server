'use strict';
/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('EmployeeAwards', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      username: {
        type: Sequelize.STRING
      },
      employee_name: {
        type: Sequelize.STRING
      },
      employee_award_name: {
        type: Sequelize.STRING
      },
      employee_award_certificate_number: {
        type: Sequelize.STRING
      },
      employee_award_area: {
        type: Sequelize.STRING
      },
      employee_award_date: {
        type: Sequelize.DATE
      },
      employee_award_remark: {
        type: Sequelize.STRING
      },
      employee_award_go_order_document: {
        type: Sequelize.STRING
      },
      employee_award_go_document_name: {
        type: Sequelize.STRING
      },
      employee_award_active_status: {
        type: Sequelize.STRING
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable('EmployeeAwards');
  }
};