const CryptoJS = require("crypto-js");
const user = require("../../../models").teachers;
require("dotenv").config();
const axios = require("axios");

const createUser = async (req, res) => {
  const { phone_number, teacherName } = req.body;

  try {
    const isMobilNumberUsed = await user.findOne({
      where: {
        phone_number: phone_number,
      },
    });

    if (isMobilNumberUsed) {
      return res.status(400).json({ message: "User already registered." });
    } else {
      // Construct the username with phone number and random number
      const username = `RPI-${phone_number}`;

      // Create a simple password (customize for better security)
      const password = phone_number.slice(3); // Example password creation

      // Hash the password using crypto-js module (SHA256 hashing algorithm)
      const hashedPassword = CryptoJS.SHA256(password).toString();

      // Create the user with the hashed password
      const newUser = await user.create({
        phone_number: phone_number,
        teacherName: teacherName,
        username: username,
        password: hashedPassword,
      });

      // Send user credentials via SMS
      const message = `Your username: ${username}, Password: ${password}`;
      // Uncomment the following lines when you're ready to send SMS
      await axios.get(
        `https://api.greenweb.com.bd/api.php?token=${process.env.SMS_TOKEN}&to=${phone_number}&message=${message}`
      );

      return res.status(201).json({
        message: "User created. Credentials sent via SMS.",
        user: { phone_number, password },
      });
    }
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
};

module.exports = {
  createUser,
};
